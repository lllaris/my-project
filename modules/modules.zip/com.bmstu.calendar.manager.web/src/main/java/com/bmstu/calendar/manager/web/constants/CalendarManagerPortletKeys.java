package com.bmstu.calendar.manager.web.constants;

/**
 * 
 * Portlet constants.
 * 
 * @author Salbieva
 */
public class CalendarManagerPortletKeys {

	public static final String CalendarManagerPortlet = "CalendarManagerPortlet";

}